const songs = [
    { title: "Let's Get It On", artist: "Marvin Gaye", file: "songs/lets_get_it_on.mp3" },
    { title: "Ain't No Mountain High Enough", artist: "Marvin Gaye & Tammi Terrell", file: "songs/aint_no_mountain.mp3" },
    { title: "Rock With You", artist: "Michael Jackson", file: "songs/rock_with_you.mp3" },
    { title: "End of the Road", artist: "Boyz II Men", file: "songs/end_of_the_road.mp3" },
    { title: "Superstition", artist: "Stevie Wonder", file: "songs/superstition.mp3" },
    { title: "Crazy Story", artist: "King Von", file: "songs/crazy_story.mp3" },
    { title: "Smells Like Teen Spirit", artist: "Nirvana", file: "songs/smells_like_teen_spirit.mp3" },
    { title: "Blinding Lights", artist: "The Weeknd", file: "songs/blinding_lights.mp3" },
    { title: "Shape of You", artist: "Ed Sheeran", file: "songs/shape_of_you.mp3" },
    { title: "River Flows in You", artist: "Yiruma", file: "songs/river_flows_in_you.mp3" }
];

const songList = document.getElementById("song-list");
const playPauseButton = document.getElementById("play-pause");
const prevButton = document.getElementById("prev");
const nextButton = document.getElementById("next");
const volumeControl = document.getElementById("volume");
const progressBar = document.getElementById("progress-bar");
const currentTimeDisplay = document.getElementById("current-time");
const totalTimeDisplay = document.getElementById("total-time");

let audio = new Audio();
let currentSongIndex = 0;

// Load playlist
songs.forEach((song, index) => {
    const li = document.createElement("li");
    li.textContent = `${song.title} - ${song.artist}`;
    li.dataset.index = index;
    li.addEventListener("click", () => loadSong(index));
    songList.appendChild(li);
});

// Load selected song
function loadSong(index) {
    currentSongIndex = index;
    audio.src = songs[index].file;
    playPauseButton.textContent = "▶️";
    audio.pause();

    // Update total time when metadata is loaded
    audio.addEventListener("loadedmetadata", () => {
        totalTimeDisplay.textContent = formatTime(audio.duration);
    });

    updateUI();
}

// Update UI
function updateUI() {
    const song = songs[currentSongIndex];
    progressBar.value = 0;
    currentTimeDisplay.textContent = "0:00";
}

// Play/Pause button
playPauseButton.addEventListener("click", () => {
    if (audio.paused) {
        audio.play();
        playPauseButton.textContent = "⏸️";
    } else {
        audio.pause();
        playPauseButton.textContent = "▶️";
    }
});

// Navigation buttons
prevButton.addEventListener("click", () => {
    currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    loadSong(currentSongIndex);
    audio.play();
});

nextButton.addEventListener("click", () => {
    currentSongIndex = (currentSongIndex + 1) % songs.length;
    loadSong(currentSongIndex);
    audio.play();
});


volumeControl.addEventListener("input", (e) => {
    audio.volume = e.target.value;
});


audio.addEventListener("timeupdate", () => {
    progressBar.value = (audio.currentTime / audio.duration) * 100;
    currentTimeDisplay.textContent = formatTime(audio.currentTime);
});

progressBar.addEventListener("input", (e) => {
    audio.currentTime = (e.target.value / 100) * audio.duration;
});


function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? "0" + secs : secs}`;
}


loadSong(currentSongIndex);
